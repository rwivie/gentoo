#!/bin/sh

# This script is used to create the configure script
cd config
make
cd ..
